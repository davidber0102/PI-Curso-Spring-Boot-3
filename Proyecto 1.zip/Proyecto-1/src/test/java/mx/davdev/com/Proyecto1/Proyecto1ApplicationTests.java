package mx.davdev.com.Proyecto1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proyecto1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
